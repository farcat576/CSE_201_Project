package com.mygdx.tankstars;

public class Settings {
}
