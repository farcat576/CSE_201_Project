package com.mygdx.tankstars;

public class Shop {
}
