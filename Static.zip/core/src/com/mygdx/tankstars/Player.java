package com.mygdx.tankstars;

public class Player {
}
