package com.mygdx.tankstars;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.math.Vector2;

//public class Abrams extends Tank{
    //public Abrams(){
    //    super([],800,"img","description");
    //    this.img.setScale(4);
    //    this.position= new Vector2(Gdx.graphics.getWidth()/2,this.img.getScaleY()*this.img.getHeight()/2);
    //}
//}
