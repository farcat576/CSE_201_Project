<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="TileSet1" tilewidth="10" tileheight="10" tilecount="1" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="10" height="10" source="tile0.png"/>
 </tile>
</tileset>
